package ics372.assignment1.controller;

public class ShippingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
