package ics372.assignment1.model;

public class Shipment {

}
