module GroupAssignment1 {
	requires org.junit.jupiter.api;
	requires json.simple;
}